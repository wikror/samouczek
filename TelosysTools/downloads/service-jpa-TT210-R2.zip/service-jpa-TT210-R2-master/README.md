service-springmvc-jpa
=====================

Telosys - Service layer - this is the link between "front-springmvc" and "persistence_jpa" templates
Telosys - Couche Service - Lié aux bundles front-springmvc et persistance_jpa
