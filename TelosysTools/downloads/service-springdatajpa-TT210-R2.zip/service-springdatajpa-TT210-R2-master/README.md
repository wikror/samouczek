service-springmvc-springdatajpa
===============================

Telosys - Couche Service - Lié aux bundles front-springmvc et persistence-springdatajpa
